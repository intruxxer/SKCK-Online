<?php $this->load->view('vwHeader'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('vwFooter'); ?>