<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Beranda extends CI_Controller {

	public function index()
	{
		/* 
			GET SESSION DATA
			$this->session->userdata('userid');
			$this->session->userdata('username');
			$this->session->userdata('role');
			$this->session->userdata('loggedin');
		*/	
		//Check Logged in
		//if($this->session->userdata('loggedin')==NULL) 
		//{
		//	redirect('login');
		//}
		$this->load->view('header');
		$this->load->view('headertitle');
		$this->load->view('navigation');
		$this->load->view('dashboard');
		$this->load->view('footer');
	}

	public function tentangskck()
	{
		$this->load->view('header');
		$this->load->view('headertitle');
		$this->load->view('navigation');
		$this->load->view('infoskck');
		$this->load->view('footer');
	}
}