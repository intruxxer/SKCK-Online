<div class="row">
  <div class="col-md-4">
  	<h1>
      <img class="text-right" src="<?php echo base_url('assets/img/logo.png'); ?>">
    </h1>
	</div>
  <div class="col-md-8">
    <h1 style="text-align:right;">Polresta Tulung Agung<br/><small>Sistem Aplikasi SKCK Online Terpadu</small></h1>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
  		
  </div>
    <div class="col-md-4">
  </div>
</div>