 <div class="row">
    <div class="col-md-12">
      <div class="jumbotron">
        <h1>SKCK Online</h1>
        <p>Selamat Datang di Sistem Aplikasi Online Pelayanan SKCK Polres Tulung Agung.</p>
        <p><a class="btn btn-primary btn-lg" href="<?php echo base_url('apply'); ?>" role="button">Registrasi</a></p>
      </div>
    </div>
</div>