	 <div class="row">
		<div class="col-md-3">&nbsp;</div>
		<div class="col-md-6">
			<p style="text-align:center;"> <b>Sistem SKCK Online Terpadu. All rights reserved 2015-2016. </b></p>
			<p style="text-align:center;">&copy; Sat Intelkam Polresta Tulung Agung & <a href="http://hasanah-consulting.com">Hasanah IT Consulting</a></p>
			<p style="text-align:center;">  Page rendered in <strong>{elapsed_time}</strong> seconds.</p>
		</div>
		<div class="col-md-3">&nbsp;</div>
	 </div>

</div> <!-- div container> -->  
</body>
</html>